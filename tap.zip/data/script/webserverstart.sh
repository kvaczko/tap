#!/bin/bash

current_date=$(date +"%Y%m%d")
current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
logfile="/data/log/$current_date.log"

touch $logfile

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" webserverstart.sh  Built-in webserver start script (webserverstart.sh)" >>$logfile

if pgrep -x "flask" >/dev/null
then
	current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
	echo $current_datetime_log" webserverstart.sh  Webserver is running." >>$logfile
        current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
	echo $current_datetime_log" webserverstart.sh  Killing process..." >>$logfile
        kill -15 `pgrep -x flask` 2>> $logfile
        current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
	echo $current_datetime_log" webserverstart.sh  ...done." >>$logfile
fi

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" webserverstart.sh  Starting webserver..." >>$logfile

cd /data/website/
python3 -m venv .venv >>$logfile 2>&1
. .venv/bin/activate >>$logfile 2>&1
pip install flask >>$logfile 2>&1
pip install FLask_login >>$logfile 2>&1
#flask run --host=0.0.0.0 --port 80 >> /data/log/webserver.log &
flask run --host=0.0.0.0 --port 80 >> /data/log/webserver.log 2>&1

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" webserverstart.sh  ...done." >>$logfile
current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" webserverstart.sh  Webserver start script has finished. Exiting." >>$logfile
