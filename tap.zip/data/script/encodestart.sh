#!/bin/bash

current_date=$(date +"%Y%m%d")
current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
logfile="/data/log/$current_date.log"
ffmpeglogfile="/data/log/ffmpeg.log"
configfile="/data/website/config.txt"
recordLength="23:59:50"

serviceID="1"

touch $logfile

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" encodestart.sh     Encoder start script (encodestart.sh)" >>$logfile

if pgrep -x "ffmpeg" >/dev/null
then
	current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
	echo $current_datetime_log" encodestart.sh     FFMPEG is running." >>$logfile
        current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
	echo $current_datetime_log" encodestart.sh     Killing process..." >>$logfile
        kill -15 `pidof ffmpeg`
        current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
	echo $current_datetime_log" encodestart.sh     ...done." >>$logfile
fi

current_datetime=$(date +"%Y%m%d-%H%M%S")

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" encodestart.sh     Starting FFMPEG..." >>$logfile

if [ -f "$configfile" ]; then
  while IFS=' : ' read -r arg_name arg_value; do
      case $arg_name in
          mode)
              processmode="$arg_value"
              ;;
          multicastAddress)
              multicastAddress="$arg_value"
              ;;
          multicastPort)
              multicastPort="$arg_value"
              ;;
          serviceID)
              serviceID="$arg_value"
              ;;
          channelName)
              channelName="$arg_value"
              ;;
          videoResolution)
              videoResolution="$arg_value"
              ;;
          videoBitrate)
              videoBitrate="$arg_value"
              videoBitrate+="k"
              ;;
          audioBitrate)
              audioBitrate="$arg_value"
              audioBitrate+="k"
              ;;
      esac
  done < "$configfile"
else
  current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
  echo $current_datetime_log" encodestart.sh     Config file does not exist! Nothing to do!" >>$logfile
fi

if [ "$processmode" = "analog" ]; then
  output_file="/data/IRIS_temp/${channelName}-${current_datetime}.mkv"
  current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
  echo $current_datetime_log" encodestart.sh     Config input source:  analog" >>$logfile
  echo $current_datetime_log" encodestart.sh     Config channel name:  "$channelName >>$logfile
  echo $current_datetime_log" encodestart.sh     Config resolution:    "$videoResolution >>$logfile
  echo $current_datetime_log" encodestart.sh     Config video bitrate: "$videoBitrate >>$logfile
  echo $current_datetime_log" encodestart.sh     Config audio bitrate: "$audioBitrate >>$logfile
  echo $current_datetime_log" encodestart.sh     Output filename:      "$output_file >>$logfile

  arecord -r48000 -fS32_le -c2 | ffmpeg -y -f video4linux2 -framerate 25 -video_size 720x576 -ss 0.3 -i /dev/video0  -acodec pcm_s32le  -i -  -c:v libx264 -preset superfast -s $videoResolution -b:v $videoBitrate -c:a libvorbis -b:a $audioBitrate -pix_fmt yuv420p -map 0:v:0 -map 1:a:0 -t $recordLength -f matroska $output_file 2>>$ffmpeglogfile

fi

if [ "$processmode" = "multicast" ]; then
  output_file="/data/IRIS_temp/${channelName}-${current_datetime}.mkv"

  current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
  echo $current_datetime_log" encodestart.sh     Config input source:  multicast" >>$logfile
  echo $current_datetime_log" encodestart.sh     Config channel name:  "$channelName >>$logfile
  echo $current_datetime_log" encodestart.sh     Config multicast:     udp://"$multicastAddress":"$multicastPort >>$logfile
  echo $current_datetime_log" encodestart.sh     Config resolution:    "$videoResolution >>$logfile
  echo $current_datetime_log" encodestart.sh     Config video bitrate: "$videoBitrate >>$logfile
  echo $current_datetime_log" encodestart.sh     Config audio bitrate: "$audioBitrate >>$logfile
  multicastPort+="?fifo_size=50000000&overrun_nonfatal=1&timeout=300000000"
  ffmpeg -y -i "udp://$multicastAddress:$multicastPort" -c:v libx264 -preset superfast -s $videoResolution -b:v $videoBitrate -c:a libvorbis -b:a $audioBitrate -v error -map 0:p:$serviceID:0 -map 0:p:$serviceID:1 -t $recordLength -f matroska $output_file 2>> $ffmpeglogfile

fi

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" encodestart.sh     Recording has finished." >>$logfile

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" encodestart.sh     Moving file from /data/IRIS_temp/ to /data/IRIS/" >>$logfile

mv /data/IRIS_temp/* /data/IRIS/ 2>> $logfile

current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" encodestart.sh     ...done." >>$logfile
current_datetime_log=$(date +"%Y/%m/%d %H:%M:%S")
echo $current_datetime_log" encodestart.sh     Encoder start script has finished. Exiting." >>$logfile


